<?php return array('dependencies' => array(), 'version' => '2e7c4a438779d8bf3986');
