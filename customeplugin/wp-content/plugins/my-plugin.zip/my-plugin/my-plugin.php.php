<?php
/** 

* Plugin Name: My Plugin
* Description: This is a test plugin
* Version: 1.1.0
* AUthor: Pathik Patel
* Author URI: https://www.flipkart.com/


*/
if(!defined('ABSPATH')){
    header("Location: /customeplgin");
    die("can't Access");
}

function my_plugin_activation()
{
  global $wpdb, $table_prefix;
  $wp_emp = $table_prefix.'emp';
//   CREATE TABLE `customeplugin`.`wp_emp` (`ID` INT NOT NULL AUTO_INCREMENT , `name` 
//   VARCHAR(50) NOT NULL , `email` VARCHAR(50) NOT NULL , `status` BOOLEAN NOT NULL 
//   , PRIMARY KEY (`ID`)) ENGINE = InnoDB;

// Create Table Query
  $q = "CREATE TABLE IF NOT EXISTS `$wp_emp` (`ID` INT NOT NULL AUTO_INCREMENT , `name` 
        VARCHAR(50) NOT NULL , `email` VARCHAR(50) NOT NULL , `status` BOOLEAN NOT NULL , 
        PRIMARY KEY (`ID`)) ENGINE = InnoDB; ";
         $wpdb->query($q);
         
         // insert Data Query
        
         //  $q = "INSERT INTO `$wp_emp` (`name`,`email`,`status`) VALUES ('Pathik', 'p4pathik424@gmail.com',1);";
        $data = array(
            'name'=>'NIrav',
            'email' => 'niravp1342@gmail.com',
            'status' => 1

        );
         $wpdb->insert($wp_emp, $data);
        
}
register_activation_hook(__FILE__, 'my_plugin_activation');

function my_plugin_deactivation()
{
    // Delete Table
    global $wpdb, $table_prefix;
    $wp_emp = $table_prefix. 'emp';
    
//if Delete Table Karvu hoy to 
    $q = "DROP TABLE `$wp_emp`";

//if TRUNCATE Table Karvu hoy to 
    // $q = "TRUNCATE `$wp_emp`";
    
    
    // $q = 
    $wpdb->query($q);
}
register_deactivation_hook(__FILE__, 'my_plugin_deactivation');




?>